<%*
const tagsInput = await tp.system.prompt("Enter encounter tags (comma-separated)?");
const count = await tp.system.prompt("How many enemies?");
const num = parseInt(count);

const baseTags = ["swn", "encounter"];
const extraTags = tagsInput
  ? tagsInput.split(",").map(t => t.trim()).filter(t => t.length > 0)
  : [];
const allTags = baseTags.concat(extraTags);

let result = "";
for (let i = 0; i < num; i++) {
  const block = await tp.user.insertCombatant(tp);
  result += block + "\n\n";
}

tR += `---
title: ${tp.file.title}
type: encounter
tags:
${allTags.map(t => `  - ${t}`).join("\n")}
---

# 🧠 Encounter: ${tp.file.title}

- **Date:** ${tp.date.now("YYYY-MM-DD")}
- **Round:** 1

## 🔢 Initiative Order

Write names + initiative here in sorted order:

1. 

---

## 🧍 Player Characters

- [ ] **Name** — Init: __ — HP __ / __
- [ ] **Name** — Init: __ — HP __ / __

---

## 💀 Enemy Combatants

${result}
`
%>
