<%*
let wType = await tp.system.suggester(
  ["Melee", "Ranged", "Explosive", "Energy", "Pretech", "Other"],
  ["Melee", "Ranged", "Explosive", "Energy", "Pretech", "Other"],
  false,
  "Select weapon type"
)
if (wType === "Other") {
  wType = await tp.system.prompt("Enter custom weapon type")
}

let tech = await tp.system.suggester(
  ["TL0", "TL1", "TL2", "TL3", "TL4", "TL4+", "Pretech"],
  ["TL0", "TL1", "TL2", "TL3", "TL4", "TL4+", "Pretech"],
  false,
  "Select tech level"
)

let dmg = await tp.system.prompt("Damage (e.g. 1d8, 2d6)?")
let range = await tp.system.prompt("Effective range (if any)?")
let value = await tp.system.prompt("Market value in credits?")
let faction = await tp.system.prompt("Any associated faction or origin?")

tR += `---
title: ${tp.file.title}
tags:
	- swn
	- weapon
type: weapon
weapon_type: ${wType}
tech_level: ${tech}
damage: ${dmg}
range: ${range}
value: ${value}
faction: ${faction}
---

# ⚔ Weapon: ${tp.file.title}

- **Type:** ${wType}
- **Tech Level:** ${tech}
- **Damage:** ${dmg}
- **Range:** ${range}
- **Value:** ${value} cr
- **Faction/Origin:** ${faction}

## Description

## Special Properties

## Lore / History

## Hooks or Uses
`
%>
